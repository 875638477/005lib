"""Run only task-owned Cadence processes, hidden, with isolated runtime paths."""
from pathlib import Path
import subprocess, os, datetime, json, shutil, sys, hashlib, ctypes
from ctypes import wintypes
B=Path(__file__).resolve().parent
CAD=Path(r'C:\Program0\Cadence\SPB172')
EXE=CAD/'tools/bin'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def identity(proc):
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
    kernel.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
    buf=ctypes.create_unicode_buffer(32768); size=wintypes.DWORD(len(buf))
    if not kernel.QueryFullProcessImageNameW(int(proc._handle),0,buf,ctypes.byref(size)):raise ctypes.WinError(ctypes.get_last_error())
    times=[wintypes.FILETIME() for _ in range(4)]
    if not kernel.GetProcessTimes(int(proc._handle),*[ctypes.byref(t) for t in times]):raise ctypes.WinError(ctypes.get_last_error())
    stamp=times[0].dwLowDateTime+(times[0].dwHighDateTime<<32)
    return dict(pid=proc.pid,creation_filetime=stamp,executable=buf.value)
def run(label,args,timeout=40,pad_warning=False):
    out=B/'logs'/label; out.mkdir(exist_ok=True)
    if (out/'launch.json').exists():
        previous=json.loads((out/'launch.json').read_text())
        if previous.get('exitCode')==0:raise RuntimeError('Successful phase already recorded: '+label)
        attempt=2
        while (B/'logs'/(label+'_attempt'+str(attempt))).exists():attempt+=1
        out=B/'logs'/(label+'_attempt'+str(attempt));out.mkdir()
    env=os.environ.copy()
    env['ALLEGRO_PCBENV']=str(out/'pcbenv'); (out/'pcbenv').mkdir(exist_ok=True)
    env['TEMP']=env['TMP']=str(B/'runtime')
    env['CDSROOT']=str(CAD)
    if label=='export_verify':
        shutil.copyfile(B/'models/md2_NGFF_M_SMT.step',out/'md2_NGFF_M_SMT.step')
        (out/'pcbenv/env').write_text('set steppath = '+(B/'models').as_posix()+'\n',encoding='ascii')
    if label=='export_local':
        shutil.copyfile(B/'models/md2_NGFF_M_SMT.step',out/'md2_NGFF_M_SMT.step')
    if label=='step_export':
        env['ALLEGRO_TEXT']=str(CAD/'share/pcb/text')
        env['ALLEGRO_INSTALL_ROOT']=str(CAD)
        env['ALLEGRO_INSTALL_DIR']=str(CAD/'share/pcb')
        (out/'pcbenv/env').write_text('set steppath = '+(B/'models').as_posix()+'\n',encoding='ascii')
    env['PATH']=str(EXE)+os.pathsep+env.get('PATH','')
    si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        native_args=[a.as_posix() if isinstance(a,Path) else str(a) for a in args]
        p=subprocess.Popen(native_args,cwd=out,env=env,stdout=stdout,stderr=stderr,startupinfo=si,creationflags=subprocess.CREATE_NO_WINDOW)
        ident=identity(p)
        record=dict(label=label,args=list(map(str,args)),startUTC=started,purpose='MD2 M-key 3D association '+label,**ident)
        (out/'launch.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
        terminated=False
        try: code=p.wait(timeout)
        except subprocess.TimeoutExpired:
            # Only dismiss a task-owned, successfully imported NPTH warning process.
            if pad_warning and list(out.glob('*.pad')) and p.poll() is None and identity(p)==ident:
                p.terminate(); code=p.wait(10);terminated=True
            else:
                raise RuntimeError('Owned native process still running; inspect '+str(out/'launch.json'))
        record.update(exitCode=code,terminated_owned_npth_warning=terminated,completed_normally=not terminated)
        (out/'launch.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(record),flush=True)
    if code and not terminated:raise RuntimeError('Native process failed: '+label)
    return out


phase=sys.argv[1]
out=B/'logs'/phase;out.mkdir(exist_ok=True)
if phase=='step_export':
    pcbenv=out/'pcbenv';pcbenv.mkdir(exist_ok=True)
    (pcbenv/'env').write_text('set steppath = '+(B/'models').as_posix()+'\n',encoding='ascii')
    run(phase,[EXE/'step_out.exe','-u','MILLIMETER','-o',B/'verification/allegro_placed_models.stp','-m',B/'verification/md2_3d_placement.brd'],60)
else:
    target={'before':B/'backups/md2_NGFF_M_SMT.dra','apply':B/'library/md2_NGFF_M_SMT.dra','after':B/'library/md2_NGFF_M_SMT.dra','board':B/'verification/md2_3d_placement.brd','board_read':B/'verification/md2_3d_placement.brd','step_export_skill':B/'verification/md2_3d_placement.brd','export_verify':B/'verification/md2_3d_placement.brd','export_local':B/'verification/md2_3d_placement.brd'}[phase]
    readonly=phase in ['before','after','board_read','step_export_skill','export_verify','export_local']
    before=sha(target) if readonly else None
    cmd=[EXE/'allegro.exe','-product','Allegro_performance','-safe','-nographic']
    if readonly:cmd.append('-readonly')
    if target.suffix=='.dra':cmd+=['-symbol','package']
    cmd+=['-s',B/'scripts'/(phase+'.scr'),'-p',out,target]
    run(phase,cmd,50)
    if before:assert sha(target)==before,'Read-only native hash changed'
