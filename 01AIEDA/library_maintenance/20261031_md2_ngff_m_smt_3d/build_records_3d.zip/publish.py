"""Reviewable publication of exactly two renamed library files and one STEP."""
from pathlib import Path
import json,hashlib,shutil,zipfile,sys
B=Path(__file__).resolve().parent
LEARN=Path(r'D:\001DIY\005lib\01AIEDA')
REC=LEARN/'library_maintenance/20261031_md2_ngff_m_smt_3d'
PSM=Path(r'D:\001DIY\005lib\01Psm_lib')
STEP=Path(r'D:\001DIY\005lib\01_3d_step_lib')
PACK=B/'delivery';PACK.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def jwrite(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
pairs=[(B/'library/md2_NGFF_M_SMT.dra',PSM/'md2_NGFF_M_SMT.dra'),(B/'library/md2_NGFF_M_SMT.psm',PSM/'md2_NGFF_M_SMT.psm'),(B/'models/md2_NGFF_M_SMT.step',STEP/'md2_NGFF_M_SMT.step')]
phase=sys.argv[1]
if phase=='prepare':
    assert json.loads((B/'verification/validation.json').read_text())['status']=='PASS'
    assert not REC.exists(),'Record destination exists'
    before=json.loads((B/'verification/input_identity.json').read_text())
    for p in before:assert sha(Path(p['path']))==p['sha256'],'User library changed; rebase required'
    assert not pairs[-1][1].exists(),'A STEP with that name already exists'
    protected=[LEARN/'EDA.md',LEARN/'library_maintenance/INDEX.txt']
    snapshots=[]
    for p in protected:
        q=B/'backups'/(p.name+'.before');shutil.copyfile(p,q)
        snapshots.append(dict(path=str(p),sha256=sha(p),backup=q.name))
    for p in ['axlStepGet','axlStepSet']:
        shutil.copyfile(Path(r'C:\Program0\Cadence\SPB172\share\pcb\examples\skill\DOC\QIR\NEW')/(p+'.txt'),B/'verification'/(p+'.txt'))
    shutil.copyfile(Path('output/hycw19m_20261031/source/HYCW19M-05NGFF-530B.pdf'),B/'verification/HYCW19M-05NGFF-530B.pdf')
    manifest=dict(date='2026-10-31',task='Add simplified 3D STEP to renamed md2_NGFF_M_SMT package',
        before=before,protected_learning_entries=snapshots,
        files=[dict(path=str(dst),bytes=src.stat().st_size,sha256=sha(src)) for src,dst in pairs],
        validation='PASS: 93 checks; actual Allegro export 405 valid solids',
        model_type='Simplified nominal engineering model from vendor drawing, not vendor-supplied detail model',
        primary_mapping='md2_NGFF_M_SMT.step; XYZ offset=0, rotations=0; user steppath already points to requested library')
    jwrite(B/'manifest.json',manifest)
    include=[]
    for sub in ['backups','library','models','scripts','logs','verification']:
        include += [p for p in (B/sub).rglob('*') if p.is_file() and not p.name.lower().endswith('.dll')]
    include += [p for p in B.iterdir() if p.is_file() and p.suffix.lower() in ['.py','.md','.json','.png']]
    # Identical temporary model copies are redundant; retain the single models/ original.
    include=[p for p in include if not (p.parent.parent.name=='logs' and p.name=='md2_NGFF_M_SMT.step')]
    with zipfile.ZipFile(PACK/'build_records_3d.zip','w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for p in sorted(set(include)):z.write(p,p.relative_to(B).as_posix())
    with zipfile.ZipFile(PACK/'build_records_3d.zip') as z:assert z.testzip() is None
    print(json.dumps(dict(ready=True,modified_files=2,new_step=1,record=str(REC),archive_bytes=(PACK/'build_records_3d.zip').stat().st_size)))
elif phase=='publish':
    m=json.loads((B/'manifest.json').read_text(encoding='utf-8'))
    assert not REC.exists()
    for p in m['before']:assert sha(Path(p['path']))==p['sha256'],'User library changed'
    for p in m['protected_learning_entries']:assert sha(Path(p['path']))==p['sha256'],'Learning entry changed'
    assert not pairs[-1][1].exists(),'New STEP target exists'
    for (src,dst),item in zip(pairs,m['files']):assert sha(src)==item['sha256'] and str(dst)==item['path']
    # Save recovery material before replacing any user's DRA/PSM.
    REC.mkdir(parents=True)
    shutil.copytree(B/'backups',REC/'backups')
    for p in ['README.md','manifest.json','model_preview.png']:shutil.copyfile(B/p,REC/p)
    shutil.copyfile(B/'verification/validation.json',REC/'validation.json')
    shutil.copyfile(PACK/'build_records_3d.zip',REC/'build_records_3d.zip')
    # Dependency first, then editable source and compiled PSM. No other library file changes.
    for src,dst in [pairs[-1],*pairs[:-1]]:
        shutil.copyfile(src,dst);assert sha(src)==sha(dst)
    eda=LEARN/'EDA.md';raw=eda.read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n';i=raw.index(b'\n')+1
    note='**2026-10-31 md2_NGFF_M_SMT 添加 3D：** [模型、备份与验证记录](library_maintenance/20261031_md2_ngff_m_smt_3d/README.md)。按用户改名后的 01Psm_lib 封装添加 PRIMARY STEP，模型位于 01_3d_step_lib；按原厂图建立简化立贴 M.2 M Key 名义外形。原生二维读回不变，PSM 三种姿态及 Allegro 实际 STEP 导出 405 实体通过；不是原厂精细模型或实物插合认证。'
    eda.write_bytes(raw[:i]+nl+note.encode('utf-8')+nl+raw[i:])
    index=LEARN/'library_maintenance/INDEX.txt';raw=index.read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n'
    note='2026-10-31  md2_NGFF_M_SMT 添加立贴 M.2 M Key 简化 STEP：修改 01Psm_lib 同名 DRA/PSM，新增 01_3d_step_lib 同名 STEP；二维几何保持，原生重开与实际 3D 旋转/镜像导出通过。\n入口：20261031_md2_ngff_m_smt_3d/README.md\n'
    index.write_bytes(raw+nl+note.replace('\n',nl.decode()).encode('utf-8'))
    receipt=dict(published=True,files=[dict(path=str(dst),sha256=sha(dst)) for src,dst in pairs],
        archive=str(REC),backups_verified=all(sha(REC/'backups'/Path(p['path']).name)==p['sha256'] for p in m['before']),
        learning_after=[dict(path=str(p),sha256=sha(p)) for p in [eda,index]])
    assert receipt['backups_verified']
    jwrite(REC/'publication_receipt.json',receipt);jwrite(B/'publication_receipt.json',receipt)
    print(json.dumps(receipt,ensure_ascii=True))
else:raise SystemExit('Use prepare or publish')
