from pathlib import Path
import sys,json,hashlib,csv,math
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B/'deps'))
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopoDS import TopoDS
def bbox(s):
    b=Bnd_Box();BRepBndLib.Add_s(s,b);return list(b.Get())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def rows(p):
    with p.open(encoding='utf-8') as f:return list(csv.DictReader(f,delimiter='\t'))
checks=[]
def ck(name,cond,detail=None):
    checks.append(dict(name=name,passed=bool(cond),detail=detail))
    assert cond,(name,detail)
def close(a,b):return abs(a-b)<2e-5
for f in ['pins.tsv','geometry.tsv','summary.txt','symbols.tsv']:
    ck('Unchanged native readback '+f,(B/'logs/before'/f).read_bytes()==(B/'logs/after'/f).read_bytes())
mapping=(B/'logs/after/mapping.txt').read_text()
ck('Native DRA retains primary filename','NAME=md2_NGFF_M_SMT.step' in mapping)
for key in ['OFFSET_X','OFFSET_Y','OFFSET_Z','ROTATION_X','ROTATION_Y','ROTATION_Z']:
    ck('Zero '+key,key+'=0.0' in mapping)
summary=(B/'logs/after/summary.txt').read_text()
ck('Package DRC valid/zero','drcs=0 drcState=t' in summary)
bk=rows(B/'logs/board_read/symbols.tsv')
ck('Three native placed PSM instances',len(bk)==3 and all(p['pins']=='69' for p in bk))
ck('PSM mappings persist for all instances',(B/'logs/board_read/mapping.txt').read_text().count('NAME=md2_NGFF_M_SMT.step')==3)
log=(B/'logs/export_local/step_out.log').read_text()
ck('Allegro actually found STEP model','Cannot find' not in log and 'export complete' in log.lower() or ('Cannot find' not in log and 'step_out complete' in log.lower()))
native=B/'verification/allegro_placed_models.stp'
r=STEPControl_Reader();ck('Native Allegro STEP readable',r.ReadFile(native.as_posix())==IFSelect_RetDone)
ck('Native export roots',r.TransferRoots()>0)
s=r.OneShape();ck('Native exported CAD shape valid',BRepCheck_Analyzer(s).IsValid())
e=TopExp_Explorer(s,TopAbs_SOLID);count=0;housings=[]
while e.More():
    count+=1;p=TopoDS.Solid_s(e.Current());bb=bbox(p)
    if bb[3]-bb[0]>20 or bb[4]-bb[1]>20:housings.append(bb)
    e.Next()
ck('All 135 model solids loaded in each of three placements',count==405,count)
ck('Three housing shapes',len(housings)==3,housings)
# Allegro exports top seating at Z=0; bottom seating is -board thickness.
# Verify the model orientation independently of the particular board thickness.
top0=next(p for p in housings if p[0]<-30)
rot90=next(p for p in housings if p[1]>10)
bottom=next(p for p in housings if p[3]>30)
ck('Top 0 degree housing axes',close(top0[0],-35.925) and close(top0[3],-14.075) and close(top0[1],-2.85) and close(top0[4],2.85),top0)
ck('Top 90 degree housing axes',close(rot90[0],-2.85) and close(rot90[3],2.85) and close(rot90[1],14.075) and close(rot90[4],35.925),rot90)
ck('Bottom mirrored housing axes',close(bottom[0],14.075) and close(bottom[3],35.925) and close(bottom[1],-2.85) and close(bottom[4],2.85),bottom)
ck('Housing/peg Z span preserved in all placements',all(close(p[5]-p[2],6.0) for p in housings),housings)
ck('Bottom 3D is inverted relative to top',bottom[2]<-5.29 and top0[5]>5.29 and rot90[5]>5.29,housings)
model=json.loads((B/'verification/model_validation.json').read_text())
ck('Published candidate STEP hash matches validated model',sha(B/'models/md2_NGFF_M_SMT.step')==model['sha256'])
# Check each visible tin toe is on its corresponding original electrical land.
pins=rows(B/'logs/after/pins.tsv')
for c in model['contacts']:
    p=next(p for p in pins if p['number'].strip('"')==c['number'] and p['layer'].strip('"')=='ETCH/TOP')
    x,y,w,h=[float(p[k]) for k in ['x','y','w','h']]
    ck('Contact '+c['number']+' aligns to original copper',close(x,c['x']) and c['tail_y'][0]>=y-h/2-1e-6 and c['tail_y'][1]<=y+h/2+1e-6 and .15<=w)
report=dict(status='PASS',checks=checks,count=len(checks),native_export_solids=count,housing_bboxes=housings,
    model_sha256=model['sha256'],native_export_sha256=sha(native),mapping='Primary model basename, offsets 0/0/0 mm, rotations 0/0/0 degrees',
    scope='Native DRA save/PSM compile/reopen, original 2D readback unchanged, actual Allegro STEP load/export and 3D transform verification. Simplified nominal model; no physical mating or molding-detail qualification.',
    known_warning='Isolated check board uses BOARD GEOMETRY/OUTLINE; exporter warned DESIGN_OUTLINE missing. Connector-only export still loaded all 405 solids; production board outline was not changed.')
(B/'verification/validation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='PASS',checks=len(checks),actual_exported_solids=count,housing_bboxes=housings)))
