"""Create a documented simplified STEP of the HYCW19M vertical M-key socket.
Outer dimensions/slot/key/pegs follow HOAUC HYC-1804101726 pages 1 and 2.
Contact spring shape and un-dimensioned internal construction are simplified.
Uses isolated CadQuery OCP / OpenCascade, no global package installation.
"""
from pathlib import Path
import sys,json,hashlib,math,collections
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B/'deps'))
from OCP.gp import gp_Pnt,gp_Dir,gp_Ax2
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox,BRepPrimAPI_MakeCylinder
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut,BRepAlgoAPI_Fuse
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box
from OCP.STEPControl import STEPControl_Reader,STEPControl_AsIs
from OCP.STEPCAFControl import STEPCAFControl_Writer
from OCP.IFSelect import IFSelect_RetDone
from OCP.Interface import Interface_Static
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.TDataStd import TDataStd_Name
from OCP.XCAFApp import XCAFApp_Application
from OCP.XCAFDoc import XCAFDoc_DocumentTool,XCAFDoc_ColorGen
from OCP.Quantity import Quantity_Color,Quantity_TOC_RGB
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID,TopAbs_FACE,TopAbs_REVERSED
from OCP.TopoDS import TopoDS
from OCP.TopLoc import TopLoc_Location
from OCP.BRep import BRep_Tool
from OCP.BRepMesh import BRepMesh_IncrementalMesh

for n in ['models','verification','scripts','logs','backups','runtime']:(B/n).mkdir(exist_ok=True)
def box(x,y,z,dx,dy,dz):return BRepPrimAPI_MakeBox(gp_Pnt(x,y,z),dx,dy,dz).Shape()
def fuse(a,b):
    op=BRepAlgoAPI_Fuse(a,b);op.Build();assert op.IsDone()
    return op.Shape()
def bbox(s):
    b=Bnd_Box();BRepBndLib.Add_s(s,b);return list(b.Get())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()

# Housing seating plane is Z=0; locating pegs extend below it.
housing=box(-10.925,-2.85,0,21.85,5.70,5.30)
slot=box(-10.075,-.45,2.60,20.15,.90,3.0)
op=BRepAlgoAPI_Cut(housing,slot);op.Build();assert op.IsDone();housing=op.Shape()
housing=fuse(housing,box(5.575,-.45,2.60,1.10,.90,2.70))
for x,d in [(-10,.95),(10,1.45)]:
    peg=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(x,0,-.70),gp_Dir(0,0,1)),d/2,.70).Shape()
    housing=fuse(housing,peg)
parts=[('Housing_with_M_key_and_locating_pegs',housing,(.08,.09,.11))]
contacts=[]
for n in range(1,76):
    if 59<=n<=66:continue
    odd=n%2
    x=(-9.25+(n-1)*.25) if odd else (-9+(n-2)*.25)
    # Tin tail is inside the vendor recommended land, with 0.15 nominal width.
    if odd:
        tail=box(x-.075,2.70,0,.15,.53,.15)
        stem=box(x-.075,2.70,.10,.15,.12,3.60)
        bridge=box(x-.075,.40,3.55,.15,2.42,.15)
        contact=box(x-.075,.35,3.55,.15,.15,1.25)
    else:
        tail=box(x-.075,-3.23,0,.15,.53,.15)
        stem=box(x-.075,-2.82,.10,.15,.12,3.60)
        bridge=box(x-.075,-2.82,3.55,.15,2.42,.15)
        contact=box(x-.075,-.50,3.55,.15,.15,1.25)
    metal=fuse(fuse(tail,stem),bridge)
    parts.append((f'Tin_terminal_{n}',metal,(.70,.73,.76)))
    parts.append((f'Gold_contact_{n}',contact,(.78,.57,.15)))
    contacts.append(dict(number=str(n),x=x,side='positive_Y' if odd else 'negative_Y',tail_y=[2.70,3.23] if odd else [-3.23,-2.70],tail_z=[0,.15]))
for name,shape,color in parts:assert BRepCheck_Analyzer(shape).IsValid(),name

app=XCAFApp_Application.GetApplication_s()
doc=TDocStd_Document(TCollection_ExtendedString('MDTV-XCAF'))
app.NewDocument(TCollection_ExtendedString('MDTV-XCAF'),doc)
st=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
ct=XCAFDoc_DocumentTool.ColorTool_s(doc.Main())
for name,shape,color in parts:
    label=st.AddShape(shape,False)
    TDataStd_Name.Set_s(label,TCollection_ExtendedString(name))
    ct.SetColor(label,Quantity_Color(*color,Quantity_TOC_RGB),XCAFDoc_ColorGen)
writer=STEPCAFControl_Writer()
writer.SetColorMode(True);writer.SetNameMode(True)
Interface_Static.SetCVal_s('write.step.schema','AP214IS')
assert writer.Transfer(doc,STEPControl_AsIs)
model=B/'models/md2_NGFF_M_SMT.step'
assert writer.Write(model.as_posix())==IFSelect_RetDone

# Independent STEP re-import and kernel checks, rather than export success alone.
r=STEPControl_Reader();assert r.ReadFile(model.as_posix())==IFSelect_RetDone
assert r.TransferRoots()>0
shape=r.OneShape();assert BRepCheck_Analyzer(shape).IsValid()
bb=bbox(shape)
assert all(abs(a-b)<1e-5 for a,b in zip(bb,[-10.925,-3.23,-.70,10.925,3.23,5.30])),bb
explorer=TopExp_Explorer(shape,TopAbs_SOLID);solids=0
while explorer.More():solids+=1;explorer.Next()
assert solids==135,solids
report=dict(model=model.name,status='VALID_REIMPORTED_STEP',source='HOAUC HYC-1804101726 PDF pages 1 and 2, user chose vendor-recommended footprint',
    classification='SIMPLIFIED_ENGINEERING_VISUAL_MODEL_NOT_VENDOR_SUPPLIED',units='mm',bbox=bb,solid_count=solids,
    nominal_body=[21.85,5.70,5.30],lead_outer_span=6.46,slot_width=.90,slot_floor_z=2.60,key_center_x=6.125,key_width=1.10,
    locating_pegs=[dict(x=-10,y=0,diameter=.95,projection=.70),dict(x=10,y=0,diameter=1.45,projection=.70)],
    contacts=contacts,sha256=sha(model),zero_mapping='Already aligned: footprint X/Y axes; Z=0 seating plane; rotations and offsets all zero.',
    simplifications=['Spring curvature and un-dimensioned internal metal simplified as connected rectangular elements.',
                     'Housing undercuts, lead forming radii, molding details and tolerances are not modeled.',
                     'No plugged-in M.2 module or support bracket is included; nominal connector only.'])
(B/'verification/model_validation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')

# Tessellate the actual written/reimportable CAD geometry for a review image.
triangles=[]
for name,part,col in parts:
    BRepMesh_IncrementalMesh(part,.04,False,.25,True).Perform()
    e=TopExp_Explorer(part,TopAbs_FACE)
    while e.More():
        face=TopoDS.Face_s(e.Current());loc=TopLoc_Location()
        mesh=BRep_Tool.Triangulation_s(face,loc)
        if mesh is not None:
            tr=loc.Transformation()
            for i in range(1,mesh.NbTriangles()+1):
                ids=list(mesh.Triangle(i).Get())
                if face.Orientation()==TopAbs_REVERSED:ids.reverse()
                pts=[]
                for j in ids:
                    p=mesh.Node(j).Transformed(tr);pts.append([p.X(),p.Y(),p.Z()])
                triangles.append(dict(points=pts,color=col))
        e.Next()
(B/'verification/model_mesh.json').write_text(json.dumps(triangles),encoding='utf-8')
print(json.dumps(dict(model=str(model),sha256=report['sha256'],valid=True,solids=solids,triangles=len(triangles))))
