"""Terminate only the specifically recorded hung task instance after identity checks."""
from pathlib import Path
import ctypes,json
from ctypes import wintypes
B=Path(__file__).resolve().parent
record_path=B/'logs/step_export_skill/launch.json'
r=json.loads(record_path.read_text())
assert r['purpose']=='MD2 M-key 3D association step_export_skill'
assert r['args'][-1].endswith('verification\\md2_3d_placement.brd')
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
k.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
k.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
k.TerminateProcess.argtypes=[wintypes.HANDLE,wintypes.UINT]
k.CloseHandle.argtypes=[wintypes.HANDLE]
h=k.OpenProcess(0x1000|0x1,False,r['pid'])
if not h:raise ctypes.WinError(ctypes.get_last_error())
try:
    b=ctypes.create_unicode_buffer(32768);n=wintypes.DWORD(len(b))
    assert k.QueryFullProcessImageNameW(h,0,b,ctypes.byref(n))
    ts=[wintypes.FILETIME() for _ in range(4)]
    assert k.GetProcessTimes(h,*[ctypes.byref(t) for t in ts])
    creation=ts[0].dwLowDateTime+(ts[0].dwHighDateTime<<32)
    assert creation==r['creation_filetime'] and b.value.lower()==r['executable'].lower(),'PID ownership mismatch'
    assert k.TerminateProcess(h,1)
    r.update(exitCode=1,terminated_verified_owned_timeout=True,reason='Missing script at launch left this task-created nographic instance waiting; script subsequently created for a fresh attempt.')
    record_path.write_text(json.dumps(r,indent=2),encoding='utf-8')
    print(json.dumps(dict(terminated_task_pid=r['pid'],creation_time_and_executable_verified=True)))
finally:k.CloseHandle(h)
