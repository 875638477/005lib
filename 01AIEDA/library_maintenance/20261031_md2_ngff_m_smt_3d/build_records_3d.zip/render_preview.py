from pathlib import Path
import json,math,sys
sys.path.append('C:/Program0/KiCad90/bin/Lib/site-packages')
import numpy as np
from PIL import Image,ImageDraw,ImageFont
B=Path(__file__).resolve().parent
mesh=json.loads((B/'verification/model_mesh.json').read_text())
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def sub(a,b):return [x-y for x,y in zip(a,b)]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def norm(a):
    n=math.sqrt(dot(a,a));return [v/n for v in a]
img=Image.new('RGB',(1600,1020),'#eef2f7');d=ImageDraw.Draw(img)
font=lambda size:ImageFont.truetype('C:/Windows/Fonts/arial.ttf',size)
d.text((800,42),'md2_NGFF_M_SMT  |  Vertical M.2 M-key',anchor='mm',font=font(32),fill='#1f344c')
d.text((800,88),'Simplified STEP from HOAUC drawing  |  nominal dimensions, not a vendor-supplied detailed model',anchor='mm',font=font(21),fill='#53677e')
def panel(camera,rect,title):
    view=norm(camera);right=norm(cross([0,0,1],view));up=cross(view,right)
    if camera[2]<0:up=[-v for v in up];right=[-v for v in right]
    def p(a):return (dot(a,right),-dot(a,up))
    points=[p(pt) for tri in mesh for pt in tri['points']]
    minx=min(v[0] for v in points);maxx=max(v[0] for v in points)
    miny=min(v[1] for v in points);maxy=max(v[1] for v in points)
    x0,y0,x1,y1=rect;scale=min((x1-x0)/(maxx-minx),(y1-y0)/(maxy-miny))
    cx=(x0+x1)/2;cy=(y0+y1)/2
    def pix(a):
        x,y=p(a);return (cx+(x-(minx+maxx)/2)*scale,cy+(y-(miny+maxy)/2)*scale)
    light=norm([-.2,-.7,1])
    faces=[]
    for tri in mesh:
        pts=tri['points'];n=norm(cross(sub(pts[1],pts[0]),sub(pts[2],pts[0])))
        if dot(n,view)<-.0001:continue
        brightness=.65+.35*abs(dot(n,light))
        col=tri['color']
        if max(col)<.2:col=[.22,.25,.30]
        color=tuple(min(255,int(255*c*brightness)) for c in col)
        faces.append((sum(dot(pt,view) for pt in pts)/3,[pix(pt) for pt in pts],color))
    # Depth per pixel prevents hidden lead parts from showing through housing.
    rgb=np.array(img)
    depth=np.full((img.height,img.width),-np.inf,dtype=np.float64)
    for tri in mesh:
        pts=tri['points'];normal=norm(cross(sub(pts[1],pts[0]),sub(pts[2],pts[0])))
        if dot(normal,view)<-.0001:continue
        proj=[pix(pt) for pt in pts];zs=[dot(pt,view) for pt in pts]
        (ax,ay),(bx,by),(cxp,cyp)=proj
        denom=(by-cyp)*(ax-cxp)+(cxp-bx)*(ay-cyp)
        if abs(denom)<1e-9:continue
        ix0=max(0,int(math.floor(min(q[0] for q in proj))));ix1=min(img.width-1,int(math.ceil(max(q[0] for q in proj))))
        iy0=max(0,int(math.floor(min(q[1] for q in proj))));iy1=min(img.height-1,int(math.ceil(max(q[1] for q in proj))))
        if ix0>ix1 or iy0>iy1:continue
        xx,yy=np.meshgrid(np.arange(ix0,ix1+1)+.5,np.arange(iy0,iy1+1)+.5)
        u=((by-cyp)*(xx-cxp)+(cxp-bx)*(yy-cyp))/denom
        v=((cyp-ay)*(xx-cxp)+(ax-cxp)*(yy-cyp))/denom
        w=1-u-v;zz=u*zs[0]+v*zs[1]+w*zs[2]
        old=depth[iy0:iy1+1,ix0:ix1+1]
        mask=(u>=-1e-8)&(v>=-1e-8)&(w>=-1e-8)&(zz>old)
        col=tri['color'];brightness=.65+.35*abs(dot(normal,light))
        if max(col)<.2:col=[.22,.25,.30]
        color=tuple(min(255,int(255*c*brightness)) for c in col)
        old[mask]=zz[mask];rgb[iy0:iy1+1,ix0:ix1+1][mask]=color
    img.paste(Image.fromarray(rgb))
    d.text(((x0+x1)/2,y1+44),title,anchor='mm',font=font(24),fill='#1f344c')
panel([24,-38,30],(65,180,1535,570),'Top view: M-key bridge, card slot and contact rows')
panel([24,38,-23],(220,680,1380,875),'Underside: asymmetric locating pegs')
d.text((800,953),'Body 21.85 x 5.70 x 5.30 mm  |  leads span 6.46 mm  |  peg projection 0.70 mm',anchor='mm',font=font(24),fill='#314c68')
d.text((800,990),'Footprint-aligned axes; all mapping offsets / rotations = 0.  Model preview from CAD tessellation.',anchor='mm',font=font(20),fill='#64748b')
img.save(B/'model_preview.png')
print('Rendered model_preview.png')
