from pathlib import Path
import shutil,json,hashlib
B=Path(__file__).resolve().parent
original=Path(r'D:\001DIY\005lib\01Psm_lib')
for n in ['library','scripts','logs','backups','runtime']:(B/n).mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
inputs=[]
for ext in ['dra','psm']:
    src=original/('md2_NGFF_M_SMT.'+ext)
    dst=B/'backups'/src.name
    if not dst.exists():shutil.copyfile(src,dst)
    assert sha(src)==sha(dst)
    inputs.append(dict(path=str(src),sha256=sha(src),bytes=src.stat().st_size))
    if ext=='dra' and not (B/'library'/src.name).exists():shutil.copyfile(src,B/'library'/src.name)
(B/'verification/input_identity.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
source=Path('output/hycw19m_20261031/run_native.py').read_text(encoding='utf-8').split('mode=sys.argv[1]')[0]
source=source.replace('HYCW19M connector library','MD2 M-key 3D association')
suffix='''
phase=sys.argv[1]
out=B/'logs'/phase;out.mkdir(exist_ok=True)
if phase=='step_export':
    pcbenv=out/'pcbenv';pcbenv.mkdir(exist_ok=True)
    (pcbenv/'env').write_text('set steppath = '+(B/'models').as_posix()+'\\n',encoding='ascii')
    run(phase,[EXE/'step_out.exe','-u','MILLIMETER','-o',B/'verification/allegro_placed_models.stp','-m',B/'verification/md2_3d_placement.brd'],60)
else:
    target={'before':B/'backups/md2_NGFF_M_SMT.dra','apply':B/'library/md2_NGFF_M_SMT.dra','after':B/'library/md2_NGFF_M_SMT.dra','board':B/'verification/md2_3d_placement.brd','board_read':B/'verification/md2_3d_placement.brd'}[phase]
    readonly=phase in ['before','after','board_read']
    before=sha(target) if readonly else None
    cmd=[EXE/'allegro.exe','-product','Allegro_performance','-safe','-nographic']
    if readonly:cmd.append('-readonly')
    if target.suffix=='.dra':cmd+=['-symbol','package']
    cmd+=['-s',B/'scripts'/(phase+'.scr'),'-p',out,target]
    run(phase,cmd,50)
    if before:assert sha(target)==before,'Read-only native hash changed'
'''
(B/'native_runner.py').write_text(source+suffix,encoding='utf-8')
old=Path('output/hycw19m_20261031/scripts/package.il').read_text(encoding='utf-8')
read=old[old.index('procedure(hcRead(out)'):]
(B/'scripts/read.il').write_text(read,encoding='utf-8')
for phase in ['before','apply','after','board','board_read']:
    out=B/'logs'/phase;out.mkdir(exist_ok=True)
    lines=['set NOCONFIRM',f'skill errset(load("{(B/"scripts/read.il").as_posix()}") t)',f'skill errset(load("{(B/"scripts/mapping.il").as_posix()}") t)']
    if phase=='apply':lines.append(f'skill errset(mdApply("{B.as_posix()}" "{out.as_posix()}") t)')
    elif phase=='board':lines.append(f'skill errset(mdBoard("{B.as_posix()}" "{out.as_posix()}") t)')
    else:lines.append(f'skill errset(mdRead("{B.as_posix()}" "{out.as_posix()}") t)')
    lines+=['quit','fillin "yes"']
    (B/'scripts'/(phase+'.scr')).write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(dict(backed_up=inputs,prepared=True)))
