md2_3d_placement.brd
