"""Prepare an isolated Cadence 17.2 connector library from the vendor drawing.
Library procedures are adapted from the user's 01AIEDA lesson 10/12 examples.
No installed files, public libraries, environment settings, or user designs change.
"""
from pathlib import Path
import json, hashlib, shutil, csv, collections

B = Path(__file__).resolve().parent
L = B / 'library'
S = B / 'scripts'
for p in [L, S, B/'logs', B/'runtime', B/'verification']:
    p.mkdir(exist_ok=True)
def write(p, text):
    p.write_text(text, encoding='utf-8', newline='\n')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest().upper()

mpn='HYCW19M-05NGFF-530B'
footprint='hycw19m_05ngff_530b'
numbers=[n for n in range(1,76) if n not in range(59,67)]
lands=[]
for n in numbers:
    odd=n%2
    x=(-9.25+(n-1)//2*.5) if odd else (-9+(n-2)//2*.5)
    lands.append(dict(number=str(n), x=x, y=2.955 if odd else -2.955, w=.3, h=1.55))
spec={
    'mpn':mpn, 'manufacturer':'HOAUC', 'footprint':footprint,
    'date':'2026-10-31', 'timezone':'Asia/Shanghai',
    'drawing':'HYC-1804101726, 2014-02-23, PDF pages 1 and 2',
    'source_url':'https://datasheet.lcsc.com/datasheet/pdf/0c8f0aea702c50be2a9d31f3da0cb37a.pdf?productCode=C41430861',
    'source_sha256':sha(B/'source'/f'{mpn}.pdf'),
    'view':'Recommended PCB Layout (TOP VIEW), page 2; +X right, +Y up; pin1 upper left',
    'origin':'Midpoint of the two locating holes; both hole centers lie on Y=0',
    'dimension_chain':'Odd X=-9.25+0.5*(n-1)/2; even X=-9+0.5*(n-2)/2; Y=+/- (3.73-1.55/2)=+/-2.955',
    'missing_numbers':list(range(59,67)), 'lands':lands,
    'holes':[dict(x=-10,y=0,d=1.10,pad='hycw19m_npth110'),dict(x=10,y=0,d=1.60,pad='hycw19m_npth160')],
    'body':[[-10.925,-2.85],[10.925,2.85]],
    'height_nominal_mm':5.30, 'height_max_mm':5.55,
    'height_basis':'Page 1 side view: 5.30 to seating plane C; general X.XX tolerance +/-0.25 mm; 0.70 peg projection is below seating plane, separate from body height.',
    'place_bound':[[-11.325,-4.03],[11.325,4.03]],
    'mask_expansion_per_side_mm':.05, 'paste':'1:1 copper; assembly/stencil process is not defined by vendor drawing',
    'schematic':'Single unit, 67 visible passive pins P1..P75 excluding 59..66; no hidden/global pins; no assumed PCIe/SATA signal assignment',
    'text_anchors':'REF DES/SILKSCREEN_TOP, REF DES/ASSEMBLY_TOP, COMPONENT VALUE/ASSEMBLY_TOP all at (0,0)',
    'source_library':'01AIEDA lessons 10 and 12 native PAD/PXML, SKILL and Dbo Tcl workflows',
    'user_choice':'2026-10-31 user explicitly selected manufacturer-recommended main footprint',
}
write(B/'spec.json', json.dumps(spec,ensure_ascii=False,indent=2)+'\n')

# Preserve and parse the user's original LCSC library.  Coordinates in this
# export are mil even though the UI display unit is mm; 393.7 mil = 10 mm.
elib=B/'source/lceda_export/ProLib_1pcs_2026-10-31.elibu'
rows=[]
for line in elib.read_text(encoding='utf-8').splitlines():
    if '||' in line:
        a,b=line.split('||',1)
        rows.append((json.loads(a),json.loads(b.rstrip('|'))))
lcsc_lands=[]
for head,v in rows:
    if head['type']=='PAD':
        lcsc_lands.append(dict(number=v['num'],x=round(v['centerX']*.0254,6),y=round(v['centerY']*.0254,6),
            w=round(v['defaultPad']['width']*.0254,6),h=round(v['defaultPad']['height']*.0254,6),shape=v['defaultPad']['padType']))
assert {p['number'] for p in lcsc_lands}==set(map(str,numbers))
compare=dict(source=str(elib),sha256=sha(elib),counts=dict(collections.Counter(h['type'] for h,v in rows)),
    lcsc=dict(pads=lcsc_lands,hole_representation='Two MULTI-layer FILL circles, not HOLE records; preserved in original export, not trusted as native drills'),
    differences=['LCSC pads 0.30 x 1.20 mm OVAL, Y=+/-2.90 mm; vendor recommends 0.30 x 1.55 mm rectangles, Y=+/-2.955 mm.',
                 'LCSC 20 mm hole spacing/1.10 and 1.60 nominal diameters agree, but are stored as MULTI-layer FILL shapes.',
                 'LCSC copper outer span is 7.00 mm; vendor recommendation is 7.46 mm.',
                 'Main Cadence footprint follows vendor per explicit user choice. LCSC-sized comparison footprint uses actual mechanical NPTHs.'])
write(B/'verification/lcsc_comparison.json',json.dumps(compare,ensure_ascii=False,indent=2)+'\n')

def pad(name, w=0, h=0, hole=None, shape='RECTANGLE'):
    t=['<?xml version="1.0" encoding="UTF-8"?>','<!DOCTYPE padstack>','<padstack version="1.0">',
       f'<padstackname>{name}</padstackname>',f'<padstackusage>{"MECH_HOLE" if hole else "SMD_PIN"}</padstackusage>',
       '<units>Mm</units><accuracy>3</accuracy>']
    if hole:
        t.append(f'<drillinfo><slothole><holetype>CIRCLE</holetype><plating>N</plating><width>{hole:.3f}</width><height>{hole:.3f}</height><offset>(0;0)</offset><drillmethod>STANDARD</drillmethod></slothole><drillsymbol><figure>CIRCLE</figure><characters>N</characters><width>{hole:.3f}</width><height>{hole:.3f}</height></drillsymbol></drillinfo>')
    else:
        t.append('<drillinfo><slothole><holetype>NONE</holetype></slothole></drillinfo>')
    def layer(layer,fig,w,h):
        t.append(f'<pad><type>REGULAR_PAD</type><layer>{layer}</layer><figure>{fig}</figure><offset>(0;0)</offset><width>{w:.3f}</width><height>{h:.3f}</height></pad>')
    if hole:
        for ly in ['BEGIN_LAYER','DEFAULT_INTERNAL','END_LAYER']:
            layer(ly,'NONE',0,0)
        for ly in ['TOP_SOLDER_MASK_PAD','BOTTOM_SOLDER_MASK_PAD']:
            layer(ly,'CIRCLE',hole+.1,hole+.1)
    else:
        layer('BEGIN_LAYER',shape,w,h)
        layer('TOP_SOLDER_MASK_PAD',shape,w+.1,h+.1)
        layer('TOP_PASTE_MASK_PAD',shape,w,h)
    t.append('</padstack>')
    write(L/(name+'.pxml'),'\n'.join(t)+'\n')
pad('hycw19m_smd030x155',.3,1.55)
pad('hycw19m_lcsc030x120',.3,1.2,shape='OBLONG')
pad('hycw19m_npth110',hole=1.1)
pad('hycw19m_npth160',hole=1.6)

# Generate pin list includes both true mechanical, unnumbered NPTHs.
for variant,items,padname in [('',lands,'hycw19m_smd030x155'),('_lcsc',lcsc_lands,'hycw19m_lcsc030x120')]:
    lines=[f'list("{padname}" {p["x"]:.6f}:{p["y"]:.6f} "{p["number"]}")' for p in items]
    lines += [f'list("{h["pad"]}" {h["x"]:.3f}:0.000 nil)' for h in spec['holes']]
    write(S/('pins'+variant+'.il'),'\n'.join(lines))
    target=footprint+variant
    for mode,func in [('create','hcCreate'),('read','hcRead')]:
        out=B/'logs'/f'{mode}{variant or "_vendor"}'
        out.mkdir(exist_ok=True)
        args=f'"{B.as_posix()}" "{out.as_posix()}" "{target}" "{variant}"' if mode=='create' else f'"{out.as_posix()}"'
        write(S/f'{mode}{variant or "_vendor"}.scr',f'set NOCONFIRM\nskill errset(load("{(S/"package.il").as_posix()}") t)\nskill errset({func}({args}) t)\nquit\nfillin "yes"\n')

# Readback procedure reuses the established official SKILL exporter, independent
# of the create routine. No calls into original mutable project state.
lesson=Path(r'D:\001DIY\005lib\01AIEDA\learning\examples\lesson10_connector_20261018\scripts\lesson10.il').read_text(encoding='utf-8')
read=lesson[lesson.index('procedure(l10Read(out)'):].replace('l10Read','hcRead').replace('L10_READ','HC_READ')
package=r'''
procedure(hcCreate(base out target variant)
 let((f style p pintext result line input cases bound layer x)
  unless(equal(axlCurrentDesign() target) error("Wrong task drawing\n"))
  unless(equal(axlDesignType(t) "PACKAGE") error("Wrong design type\n"))
  axlDBChangeDesignUnits("millimeters" 3)
  unless(axlDBChangeDesignExtents(list(-50:-50 50:50)) error("Extents failed\n"))
  axlSetVariable("padpath" list(strcat(base "/library")))
  axlSetVariable("psmpath" list(strcat(base "/library")))
  f=outfile(strcat(out "/create.txt"))
  fprintf(f "HC_CREATE START\n")
  style=make_axlTextOrientation(?textBlock "2" ?rotation 0 ?mirrored nil ?justify "center")
  input=infile(strcat(base "/scripts/pins" variant ".il"))
  while(gets(line input)
   cases=evalstring(line)
   p=axlLoadPadstack(car(cases))
   unless(p error("Pad load failed\n"))
   pintext=if(caddr(cases) then make_axlPinText(?number caddr(cases) ?offset 0:0 ?text style) else nil)
   result=axlDBCreatePin(p cadr(cases) pintext 0.0)
   unless(result error("Pin create failed\n"))
   fprintf(f "PIN %L %L mechanical=%L\n" car(result)->number car(result)->xy car(result)->isMech)
  )
  close(input)
  unless(axlDBCreateLine(list(-10.925:-2.85 10.925:-2.85 10.925:2.85 -10.925:2.85 -10.925:-2.85) 0.05 "PACKAGE GEOMETRY/ASSEMBLY_TOP" nil nil) error("Assembly failed\n"))
  ; Side silk and short end strokes avoid every solder-mask opening.
  foreach(x list(-11.125 11.125)
   unless(axlDBCreateLine(list(x:-3.40 x:3.40) 0.12 "PACKAGE GEOMETRY/SILKSCREEN_TOP" nil nil) error("Side silk failed\n")))
  unless(axlDBCreateLine(list(-11.125:3.40 -9.85:3.40) 0.12 "PACKAGE GEOMETRY/SILKSCREEN_TOP" nil nil) error("Pin1 silk failed\n"))
  unless(axlDBCreateLine(list(-9.50:4.10 -9.25:3.90 -9.00:4.10) 0.10 "PACKAGE GEOMETRY/SILKSCREEN_TOP" nil nil) error("Pin1 marker failed\n"))
  ; M-key slot center is x=6.125 mm (vendor page 1).
  unless(axlDBCreateLine(list(5.575:-0.75 5.575:0.75 6.675:0.75 6.675:-0.75 5.575:-0.75) 0.05 "PACKAGE GEOMETRY/ASSEMBLY_TOP" nil nil) error("Key reference failed\n"))
  result=axlDBCreateRectangle(list(-11.325:-4.03 11.325:4.03) t "PACKAGE GEOMETRY/PLACE_BOUND_TOP" nil nil)
  unless(result error("Place bound failed\n"))
  bound=car(result)
  unless(axlDBAddProp(list(bound) list("PACKAGE_HEIGHT_MAX" "5.55 MM")) error("Height failed\n"))
  ; Actual NPTHs already block drilling; explicit keepout includes 0.20 mm radial
  ; task clearance, recorded as an engineering choice, not a vendor requirement.
  unless(axlDBCreateRectangle(list(-10.75:-0.75 -9.25:0.75) t "ROUTE KEEPOUT/ALL" nil nil) error("Left hole keepout failed\n"))
  unless(axlDBCreateRectangle(list(9.0:-1.0 11.0:1.0) t "ROUTE KEEPOUT/ALL" nil nil) error("Right hole keepout failed\n"))
  foreach(layer list("REF DES/SILKSCREEN_TOP" "REF DES/ASSEMBLY_TOP")
   unless(axlDBCreateText("J*" 0:0 style layer nil) error("Reference failed\n")))
  unless(axlDBCreateText("VALUE" 0:0 style "COMPONENT VALUE/ASSEMBLY_TOP" nil) error("Value failed\n"))
  unless(axlSaveDesign(?design strcat(base "/library/" target ".dra") ?noMru t ?noConfirm t) error("Save failed\n"))
  unless(axlCompileSymbol(?symbol strcat(base "/library/" target)) error("Compile failed\n"))
  fprintf(f "HC_CREATE COMPLETE\n")
  close(f)
  t
 ))
'''
write(S/'package.il',package+'\n'+read)

# A short Tcl data file binds physical pin number to contiguous internal position.
tclrows=[]
for i,n in enumerate(numbers):
    y=10*((n-1)//2+1)
    sx,hx=(0,-20) if n%2 else (200,220)
    tclrows.append(f'  {{{n} P{n} {i} {sx} {y} {hx} {y}}}')
write(S/'pin_spec.tcl','set ::hcPins {\n'+'\n'.join(tclrows)+'\n}\n')
print(json.dumps({'prepared':str(B),'electrical_pins':len(numbers),'pad_types':4,'main_footprint':footprint,'lcsc_source_preserved':True}))
