"""Run only task-owned Cadence processes, hidden, with isolated runtime paths."""
from pathlib import Path
import subprocess, os, datetime, json, shutil, sys, hashlib, ctypes
from ctypes import wintypes
B=Path(__file__).resolve().parent
CAD=Path(r'C:\Program0\Cadence\SPB172')
EXE=CAD/'tools/bin'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def identity(proc):
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
    kernel.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
    buf=ctypes.create_unicode_buffer(32768); size=wintypes.DWORD(len(buf))
    if not kernel.QueryFullProcessImageNameW(int(proc._handle),0,buf,ctypes.byref(size)):raise ctypes.WinError(ctypes.get_last_error())
    times=[wintypes.FILETIME() for _ in range(4)]
    if not kernel.GetProcessTimes(int(proc._handle),*[ctypes.byref(t) for t in times]):raise ctypes.WinError(ctypes.get_last_error())
    stamp=times[0].dwLowDateTime+(times[0].dwHighDateTime<<32)
    return dict(pid=proc.pid,creation_filetime=stamp,executable=buf.value)
def run(label,args,timeout=40,pad_warning=False):
    out=B/'logs'/label; out.mkdir(exist_ok=True)
    if (out/'launch.json').exists():
        previous=json.loads((out/'launch.json').read_text())
        if previous.get('exitCode')==0:raise RuntimeError('Successful phase already recorded: '+label)
        attempt=2
        while (B/'logs'/(label+'_attempt'+str(attempt))).exists():attempt+=1
        out=B/'logs'/(label+'_attempt'+str(attempt));out.mkdir()
    env=os.environ.copy()
    env['ALLEGRO_PCBENV']=str(out/'pcbenv'); (out/'pcbenv').mkdir(exist_ok=True)
    env['TEMP']=env['TMP']=str(B/'runtime')
    env['CDSROOT']=str(CAD)
    env['PATH']=str(EXE)+os.pathsep+env.get('PATH','')
    si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        native_args=[a.as_posix() if isinstance(a,Path) else str(a) for a in args]
        p=subprocess.Popen(native_args,cwd=out,env=env,stdout=stdout,stderr=stderr,startupinfo=si,creationflags=subprocess.CREATE_NO_WINDOW)
        ident=identity(p)
        record=dict(label=label,args=list(map(str,args)),startUTC=started,purpose='HYCW19M connector library '+label,**ident)
        (out/'launch.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
        terminated=False
        try: code=p.wait(timeout)
        except subprocess.TimeoutExpired:
            # Only dismiss a task-owned, successfully imported NPTH warning process.
            if pad_warning and list(out.glob('*.pad')) and p.poll() is None and identity(p)==ident:
                p.terminate(); code=p.wait(10);terminated=True
            else:
                raise RuntimeError('Owned native process still running; inspect '+str(out/'launch.json'))
        record.update(exitCode=code,terminated_owned_npth_warning=terminated,completed_normally=not terminated)
        (out/'launch.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(record),flush=True)
    if code and not terminated:raise RuntimeError('Native process failed: '+label)
    return out

mode=sys.argv[1]
if mode=='pads':
    for src in sorted((B/'library').glob('*.pxml')):
        name='pad_'+src.stem
        out=B/'logs'/name;out.mkdir(exist_ok=True)
        local=out/src.name;shutil.copyfile(src,local)
        run(name,[EXE/'padstack_editor.exe','-x',local],20,pad_warning='npth' in src.stem)
        pads=list(out.glob('*.pad'));assert len(pads)==1,pads
        dst=B/'library'/pads[0].name;assert not dst.exists()
        shutil.copyfile(pads[0],dst)
elif mode in ['capture_create','capture_read']:
    target=B/'library/HYCW19M-05NGFF-530B.olb'
    before=sha(target) if mode.endswith('read') else None
    run(mode,[CAD/'tcltk/bin/tclsh.exe',B/'scripts/capture.tcl',mode.split('_')[1]])
    if before:assert before==sha(target),'OLB changed during fresh readback'
elif mode in ['board','board_read']:
    label=mode
    out=B/'logs'/label;out.mkdir(exist_ok=True)
    target=B/'verification/hycw19m_library_check.brd'
    readonly=mode=='board_read'
    before=sha(target) if readonly else None
    script=B/'scripts'/(label+'.scr')
    lines=['set NOCONFIRM',f'skill errset(load("{(B/"scripts/package.il").as_posix()}") t)']
    if readonly:lines.append(f'skill errset(hcRead("{out.as_posix()}") t)')
    else:
        lines += [f'skill errset(load("{(B/"scripts/placement.il").as_posix()}") t)',f'skill errset(hcPlace("{B.as_posix()}" "{out.as_posix()}") t)']
    lines += ['quit','fillin "yes"']
    script.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    args=[EXE/'allegro.exe','-product','Allegro_performance','-safe','-nographic']
    if readonly:args.append('-readonly')
    args+=['-s',script,'-p',out,target]
    run(label,args,45)
    if readonly:assert before==sha(target),'Check BRD changed on readback'
    else:assert 'HC_PLACE COMPLETE' in (out/'create.txt').read_text()
elif mode in ['package','read']:
    for variant in ['','_lcsc']:
        label=('create' if mode=='package' else 'read')+(variant or '_vendor')
        target=B/'library'/('hycw19m_05ngff_530b'+variant+'.dra')
        before=sha(target) if mode=='read' else None
        assert target.exists() if before else not target.exists()
        args=[EXE/'allegro.exe','-product','Allegro_performance','-safe','-nographic']
        if mode=='read':args.append('-readonly')
        args += ['-symbol','package','-s',B/'scripts'/(label+'.scr'),'-p',B/'logs'/label,target]
        run(label,args,45)
        assert target.exists(),target
        if before:assert before==sha(target),'DRA changed during readback'
        else:assert 'HC_CREATE COMPLETE' in (B/'logs'/label/'create.txt').read_text()
else:raise SystemExit('Unknown phase')
