"""Publish only the reviewed HYCW19M task files; never overwrite user input.
Run 'prepare' inside workspace first; 'publish' needs the external-directory grant.
"""
from pathlib import Path
import json, hashlib, zipfile, shutil, sys, datetime
B=Path(__file__).resolve().parent
D=Path(r'D:\001DIY\005lib\AUTOlib\HYCW19M-05NGFF-530B')
LEARN=Path(r'D:\001DIY\005lib\01AIEDA')
REC=LEARN/'library_maintenance/20261031_hycw19m_ngff_mkey'
PACK=B/'delivery'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def write_json(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def payload():
    pairs=[(p,Path(p.name)) for p in sorted((B/'library').iterdir()) if p.suffix.lower() in ['.olb','.pad','.dra','.psm']]
    pairs += [(B/n,Path(n)) for n in ['README.md','PIN_MAP.csv','spec.json','pcb_preview.png','pcb_preview.svg','pcb_lcsc_preview.png','pcb_lcsc_preview.svg','schematic_preview.png','schematic_preview.svg']]
    pairs += [(B/'source/HYCW19M-05NGFF-530B.pdf',Path('source/HYCW19M-05NGFF-530B.pdf')),
              (PACK/'build_records_20261031.zip',Path('build_records_20261031.zip'))]
    return pairs

mode=sys.argv[1]
if mode=='prepare':
    validation=json.loads((B/'verification/validation.json').read_text(encoding='utf-8'))
    assert validation['status']=='PASS'
    assert not REC.exists(),'An archive already exists; inspect instead of overwriting'
    PACK.mkdir(exist_ok=True)
    originals={p.name:dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in D.iterdir() if p.is_file()}
    assert 'ProLib_1pcs_2026-10-31.elibz2' in originals
    assert originals['ProLib_1pcs_2026-10-31.elibz2']['sha256']==sha(B/'source/ProLib_1pcs_2026-10-31.elibz2')
    protected=[LEARN/'EDA.md',LEARN/'library_maintenance/INDEX.txt']
    for p in protected:shutil.copyfile(p,PACK/(p.name+'.before'))
    plan=dict(date='2026-10-31',destination=str(D),record_destination=str(REC),input_files_before=originals,
        protected_learning_files=[dict(path=str(p),sha256=sha(p),backup=p.name+'.before') for p in protected])
    write_json(PACK/'publish_plan.json',plan)
    archive_files=[]
    for directory in ['library','logs','scripts','source','verification']:
        archive_files += [p for p in (B/directory).rglob('*') if p.is_file()]
    archive_files += [B/n for n in ['prepare.py','run_native.py','validate.py','publish.py','README.md','PIN_MAP.csv','spec.json','pcb_preview.png','pcb_preview.svg','pcb_lcsc_preview.png','pcb_lcsc_preview.svg','schematic_preview.png','schematic_preview.svg']]
    archive_files += [PACK/n for n in ['publish_plan.json','EDA.md.before','INDEX.txt.before']]
    with zipfile.ZipFile(PACK/'build_records_20261031.zip','w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for p in sorted(archive_files):z.write(p,p.relative_to(B).as_posix())
    with zipfile.ZipFile(PACK/'build_records_20261031.zip') as z:assert z.testzip() is None
    files=[]
    for src,rel in payload():
        dst=D/rel
        assert not dst.exists() or sha(dst)==sha(src),'Different target file already exists: '+str(dst)
        files.append(dict(file=rel.as_posix(),bytes=src.stat().st_size,sha256=sha(src)))
    manifest=dict(date='2026-10-31',mpn='HYCW19M-05NGFF-530B',cadence_version='17.2',recommended_symbol='HYCW19M-05NGFF-530B',recommended_footprint='hycw19m_05ngff_530b',validation='PASS',input_files_preserved=originals,files=files)
    write_json(PACK/'final_manifest.json',manifest)
    print(json.dumps(dict(ready=True,files=len(files),destination=str(D),archive_bytes=(PACK/'build_records_20261031.zip').stat().st_size)))
elif mode=='publish':
    plan=json.loads((PACK/'publish_plan.json').read_text(encoding='utf-8'))
    manifest=json.loads((PACK/'final_manifest.json').read_text(encoding='utf-8'))
    # Recheck every frozen source/target and both learning documents before any write.
    assert not REC.exists(),'Task record directory already exists'
    for item in plan['protected_learning_files']:assert sha(Path(item['path']))==item['sha256'],'Learning entry changed; rebase first'
    for name,item in plan['input_files_before'].items():assert sha(D/name)==item['sha256'],'User input changed'
    pairs=payload()
    for (src,rel),item in zip(pairs,manifest['files']):
        assert sha(src)==item['sha256'] and rel.as_posix()==item['file'],'Frozen source changed'
        assert not (D/rel).exists() or sha(D/rel)==item['sha256'],'Do not overwrite target'
    assert not (D/'final_manifest.json').exists(),'Manifest already exists'
    for src,rel in pairs:
        dest=D/rel;dest.parent.mkdir(exist_ok=True,parents=True)
        if not dest.exists():shutil.copyfile(src,dest)
        assert sha(dest)==sha(src)
    shutil.copyfile(PACK/'final_manifest.json',D/'final_manifest.json')
    REC.mkdir(parents=True)
    for n in ['build_records_20261031.zip','final_manifest.json','publish_plan.json','EDA.md.before','INDEX.txt.before']:
        shutil.copyfile(PACK/n,REC/n)
        assert sha(REC/n)==sha(PACK/n)
    shutil.copyfile(B/'README.md',REC/'README.md')
    eda=LEARN/'EDA.md';raw=eda.read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n'
    entry='**2026-10-31 HYCW19M-05NGFF-530B 立贴 NGFF M Key 建库：** [制作与验证记录](library_maintenance/20261031_hycw19m_ngff_mkey/README.md)。Cadence 17.2 原生 OLB/PAD/DRA/PSM 已生成至 AUTOlib/HYCW19M-05NGFF-530B；用户选定原厂推荐 0.30×1.55 mm 主版本，立创 0.30×1.20 mm 长圆尺寸另作对照。67 个电气接点和 2 个无铜 NPTH、独立重开、六个旋转/镜像实例已验证；GUI 像素、3D 和实物焊接不在本次验收范围。'
    idx=raw.index(b'\n')+1
    new=raw[:idx]+nl+entry.encode('utf-8')+nl+raw[idx:]
    eda.write_bytes(new)
    index=LEARN/'library_maintenance/INDEX.txt';raw=index.read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n'
    addition='2026-10-31  HYCW19M-05NGFF-530B 立贴 NGFF M Key：新建 Capture OLB、Allegro PAD/DRA/PSM；原厂推荐主版本及立创尺寸对照。\n入口：20261031_hycw19m_ngff_mkey/README.md\n交付：D:\\001DIY\\005lib\\AUTOlib\\HYCW19M-05NGFF-530B；原下载包保留，脚号/定位孔/旋转/镜像与只读重开已验证。\n'
    index.write_bytes(raw+nl+addition.replace('\n',nl.decode()).encode('utf-8'))
    for name,item in plan['input_files_before'].items():assert sha(D/name)==item['sha256']
    verified=[]
    for item in manifest['files']:
        p=D/item['file'];assert sha(p)==item['sha256'];verified.append(item['file'])
    receipt=dict(published=True,date='2026-10-31',destination=str(D),verified_files=verified,user_input_unchanged=True,
        learning_records=str(REC),learning_after=[dict(path=str(p),sha256=sha(p)) for p in [eda,index]])
    write_json(REC/'publication_receipt.json',receipt)
    write_json(B/'publication_receipt.json',receipt)
    print(json.dumps(dict(published=True,verified_files=len(verified),destination=str(D),input_unchanged=True,learning_record=str(REC)),ensure_ascii=True))
else:raise SystemExit('Use prepare or publish')
