load {C:/Program0/Cadence/SPB172/tools/bin/orDb_Dll_Tcl64.dll} DboTclWriteBasic
set ::DboSession_s_pDboSession [DboTclHelper_sCreateSession]
DboSession -this $::DboSession_s_pDboSession
set base [file normalize [file join [file dirname [info script]] ..]]
source [file join $base scripts pin_spec.tcl]
set mode [lindex $argv 0]
proc cs {s} {DboTclHelper_sMakeCString $s}
proc ck {s where} {if {[$s Failed]} {error "DboState failure: $where"}; return $s}
proc nn {v s where} {ck $s $where; if {$v eq "" || $v eq "NULL"} {error "NULL: $where"}; return $v}
proc sv {obj method args} {set b [cs ""]; ck [$obj $method {*}$args $b] $method; return [DboTclHelper_sGetConstCharPtr $b]}
proc pt {p} {list [DboTclHelper_sGetCPointX $p] [DboTclHelper_sGetCPointY $p]}
proc prop {obj k v} {set st [DboState]; nn [$obj NewUserProp [cs $k] [cs $v] $st] $st "NewUserProp $k"}
proc display {part k x y} {
 set st [DboState]
 set f [DboTclHelper_sMakeLOGFONT Arial -10 0 0 0 400 0 0 0 0 7 0 1 16]
 set p [$part NewDisplayProp $st [cs $k] [DboTclHelper_sMakeCPoint $x $y] 0 $f 48]
 nn $p $st NewDisplayProp
 ck [$p SetDisplayType 1] SetDisplayType
 $p SetHorizontalTextJustification 0
}
proc create_part {lib name footprint} {
 set st [DboState]
 set package [$lib NewPackage [cs $name] $st]; nn $package $st NewPackage
 ck [$package SetReferenceTemplate [cs J]] SetReferenceTemplate
 ck [$package SetPCBFootprint [cs $footprint]] SetPCBFootprint
 set cell [$lib NewCell [cs $name] $st]; nn $cell $st NewCell
 set part [$lib NewPart [cs "$name.Normal"] $st]; nn $part $st NewPart
 ck [$cell AddPart $part] AddPart
 $part SetCellPtr $cell; $part SetPackagePtr $package
 ck [$part SetBoundingBox [DboTclHelper_sMakeCRect 0 0 200 390]] SetBoundingBox
 ck [$part SetPartValue [cs HYCW19M-05NGFF-530B]] SetPartValue
 ck [$part SetReference [cs J]] SetReference
 ck [$part SetPinNamesAreVisible 1] NamesVisible
 ck [$part SetPinNumbersAreVisible 1] NumbersVisible
 ck [$part SetPinNamesAreRotated 0] NamesRotated
 foreach seg {{0 0 200 0} {200 0 200 390} {200 390 0 390} {0 390 0 0}} {
  lassign $seg a b c d
  nn [$part NewLine $st [DboTclHelper_sMakeCPoint $a $b] [DboTclHelper_sMakeCPoint $c $d] 0 0] $st NewLine
 }
 foreach {k v} [list Manufacturer HOAUC {Manufacturer Part Number} HYCW19M-05NGFF-530B {PCB Footprint} $footprint \
     Datasheet HYCW19M-05NGFF-530B.pdf {Source Drawing} {HYC-1804101726; recommended PCB layout TOP VIEW, page 2} \
     {Connector Type} {Vertical SMT NGFF M Key, 67 contacts, 0.5 mm pitch} \
     {Pin Policy} {P1..P75 excluding 59..66; all passive and visible; no implicit PCIe/SATA assignment} \
     {Symbol Revision} AUTO_20261031_REV1] {prop $part $k $v}
 display $part {Part Reference} 0 -20
 display $part Value 0 410
 foreach row $::hcPins {
  lassign $row number name position sx sy hx hy
  set pin [$part NewSymbolPinScalar $st [cs $name] 4 [DboTclHelper_sMakeCPoint $sx $sy] [DboTclHelper_sMakeCPoint $hx $hy] 1 $position]
  nn $pin $st "Pin $number"
  foreach {method value} {SetIsLong 1 SetIsClock 0 SetIsDot 0 SetIsLeftPointing 0 SetIsRightPointing 0 SetIsNetStyle 0 SetIsNoConnect 0 SetIsGlobal 0 SetIsVisible 1 SetIsNumberVisible 1} {
   ck [$pin $method $value] "$method pin $number"
  }
 }
 set dev [$package NewDevice [cs ""] 0 $cell $st]; nn $dev $st NewDevice
 foreach row $::hcPins {
  lassign $row number name position
  ck [$dev NewPinNumber [cs $number] [DboTclHelper_sMakeInt $position] 0 -1] "Physical pin $number"
 }
 ck [$lib SavePackageAll $package] SavePackageAll
}
proc read_part {lib name out} {
 file mkdir $out
 set st [DboState]
 set package [$lib GetPackage [cs $name] $st]; nn $package $st GetPackage
 set dev [$package GetDevice 0 $st]; nn $dev $st GetDevice
 set cell [$dev GetCell $st]; nn $cell $st GetCell
 set part [$cell FindPart 0 $st]; nn $part $st FindPart
 set f [open [file join $out pins.tsv] w]; fconfigure $f -encoding utf-8 -translation lf
 puts $f "number\tposition\tname\ttype\tvisible\tnumberVisible\tglobal\tnoConnect\tstartX\tstartY\thotX\thotY"
 set iter [$part NewLPinsIter $st]
 set pin [$iter NextPin $st]
 set count 0
 while {$pin ne "NULL"} {
  set pos [$pin GetPinPosition $st]
  puts $f [join [concat [list [sv $dev GetPinNumber $pos] $pos [sv $pin GetPinName] [$pin GetPinType $st] [$pin GetIsVisible $st] [$pin GetIsNumberVisible $st] [$pin GetIsGlobal $st] [$pin GetIsNoConnect $st]] [pt [$pin GetStartPoint $st]] [pt [$pin GetHotSpot $st]]] "\t"]
  incr count
  set pin [$iter NextPin $st]
 }
 close $f; delete_DboLibPartPinsIter $iter
 set f [open [file join $out properties.tsv] w]; fconfigure $f -encoding utf-8 -translation lf
 puts $f "property\tvalue"
 foreach k {Manufacturer {Manufacturer Part Number} {PCB Footprint} Datasheet {Source Drawing} {Connector Type} {Pin Policy} {Symbol Revision}} {
  set b [cs ""]; ck [$part GetUserPropStringValue [cs $k] $b] "Read property $k"
  puts $f "$k\t[DboTclHelper_sGetConstCharPtr $b]"
 }
 puts $f "packagePCBFootprint\t[sv $package GetPCBFootprint]"
 puts $f "packageReferenceTemplate\t[sv $package GetReferenceTemplate]"
 puts $f "deviceSuffix\t[sv $dev GetDesignator]"
 puts $f "partValue\t[sv $part GetPartValue]"
 puts $f "partPinNamesVisible\t[$part GetPinNamesAreVisible $st]"
 puts $f "partPinNumbersVisible\t[$part GetPinNumbersAreVisible $st]"
 puts $f "pinCount\t$count"
 close $f
 set f [open [file join $out vectors.tsv] w]; fconfigure $f -encoding utf-8 -translation lf
 puts $f "type\tstartX\tstartY\tendX\tendY"
 set it [$part NewVectorsIter $st $::IterDefs_ALL]
 set v [$it NextVector $st]
 while {$v ne "NULL"} {
  if {[$v GetObjectType]!=$::DboBaseObject_LINE} {error "Unexpected symbol vector"}
  set ln [DboVectorToDboLine $v]
  puts $f [join [concat LINE [pt [$ln GetStart $st]] [pt [$ln GetEnd $st]]] "\t"]
  set v [$it NextVector $st]
 }
 close $f; delete_DboGraphicObjectVectorsIter $it
 set f [open [file join $out display.tsv] w]; fconfigure $f -encoding utf-8 -translation lf
 puts $f "name\tx\ty\tdisplayType"
 set it [$part NewDisplayPropsIter $st]; set p [$it NextProp $st]
 while {$p ne "NULL"} {
  puts $f [join [concat [list [sv $p GetName]] [pt [$p GetLocation $st]] [list [$p GetDisplayType $st]]] "\t"]
  set p [$it NextProp $st]
 }
 close $f; delete_DboDisplayPropsIter $it
 if {$count!=67} {error "Expected 67 visible physical pins, got $count"}
}
set code [catch {
 set session $::DboSession_s_pDboSession
 set st [DboState]
 set path [file join $base library HYCW19M-05NGFF-530B.olb]
 if {$mode eq "create"} {
  if {[file exists $path]} {error "Refuse to overwrite library"}
  set lib [$session CreateLib [cs $path] $st]; nn $lib $st CreateLib
  create_part $lib HYCW19M-05NGFF-530B hycw19m_05ngff_530b
  create_part $lib HYCW19M-05NGFF-530B_LCSC hycw19m_05ngff_530b_lcsc
  ck [$session SaveLib $lib] SaveLib
 } elseif {$mode eq "read"} {
  set lib [$session GetLib [cs $path] $st]; nn $lib $st GetLib
  read_part $lib HYCW19M-05NGFF-530B [file join $base verification capture_vendor]
  read_part $lib HYCW19M-05NGFF-530B_LCSC [file join $base verification capture_lcsc]
 } else {error "Unknown mode"}
 ck [$session RemoveLib $lib] RemoveLib
 set result COMPLETE
} result options]
set report [dict create pid [pid] executable [info nameofexecutable] mode $mode code $code result $result]
if {$code} {dict set report errorinfo [dict get $options -errorinfo]}
set f [open [file join $base logs capture_${mode}.tcldict] w]
fconfigure $f -encoding utf-8 -translation lf
puts $f $report; close $f
puts $report
exit $code
