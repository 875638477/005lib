"""Independent audit of reopened native library and six placed PSM instances.
Vendor dimensions below are transcribed independently from PDF page 2; this
validator does not import the generator or trust its in-memory object counts.
"""
from pathlib import Path
import csv, json, math, re, hashlib, html, collections
import pymupdf
B=Path(__file__).resolve().parent
V=B/'verification'
checks=[]
def ck(name,condition,detail=None):
    checks.append(dict(check=name,passed=bool(condition),detail=detail))
    if not condition:raise AssertionError(f'{name}: {detail}')
def close(a,b):return abs(float(a)-float(b))<=.00051
def table(p):
    with p.open(encoding='utf-8') as f:
        return [{k:(v or '').strip().strip('"') for k,v in r.items()} for r in csv.DictReader(f,delimiter='\t')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def box(s):return [float(x) for x in re.findall(r'-?\d+(?:\.\d+)?',s)]
def boxeq(r,values):return all(close(r[k],v) for k,v in zip(['x1','y1','x2','y2'],values))
expected_numbers={str(n) for n in range(1,76)}-{str(n) for n in range(59,67)}
expected=[]
for n in sorted(map(int,expected_numbers)):
    expected.append(dict(number=str(n),x=-9.25+(n-1)*.25 if n%2 else -9+(n-2)*.25,
        y=2.955 if n%2 else -2.955,w=.3,h=1.55,mechanical=False))
expected += [dict(number='',x=-10,y=0,d=1.10,mechanical=True),dict(number='',x=10,y=0,d=1.60,mechanical=True)]
comparison=json.loads((V/'lcsc_comparison.json').read_text(encoding='utf-8'))
expected_lcsc=[dict(p,mechanical=False) for p in comparison['lcsc']['pads']]+expected[-2:]
ck('67 electrical contacts plus 2 mechanical holes',len(expected)==69 and len(expected_numbers)==67)
ck('vendor source hash',sha(B/'source/HYCW19M-05NGFF-530B.pdf')==json.loads((B/'spec.json').read_text())['source_sha256'])

for variant in ['vendor','lcsc']:
    r=V/('capture_'+variant)
    pins=table(r/'pins.tsv')
    ck(variant+' symbol 67 unique physical pins',len(pins)==67 and {p['number'] for p in pins}==expected_numbers)
    for p in pins:
        n=int(p['number']);idx=sorted(map(int,expected_numbers)).index(n)
        y=10*((n-1)//2+1)
        sx,hx=(0,-20) if n%2 else (200,220)
        ck(variant+f' symbol pin {n}',p['name']==f'P{n}' and int(p['position'])==idx and p['type']=='4' and p['visible']=='1' and p['numberVisible']=='1' and p['global']=='0' and p['noConnect']=='0'
           and [int(p[k]) for k in ['startX','startY','hotX','hotY']]==[sx,y,hx,y],p)
    props={p['property']:p['value'] for p in table(r/'properties.tsv')}
    fp='hycw19m_05ngff_530b'+('_lcsc' if variant=='lcsc' else '')
    ck(variant+' symbol footprint binding',props['PCB Footprint']==props['packagePCBFootprint']==fp)
    ck(variant+' single unit and J reference',props['deviceSuffix']=='' and props['packageReferenceTemplate']=='J')
    vectors=table(r/'vectors.tsv')
    ck(variant+' native symbol body',len(vectors)==4 and {tuple(int(p[k]) for k in ['startX','startY','endX','endY']) for p in vectors}=={(0,0,200,0),(200,0,200,390),(200,390,0,390),(0,390,0,0)})
    disp=table(r/'display.tsv')
    ck(variant+' reference/value visible',len(disp)==2 and {d['name'] for d in disp}=={'Part Reference','Value'} and all(d['displayType']=='1' for d in disp))

def transform(x,y,sx,sy,a,m):
    if m:x=-x
    if a==90:x,y=-y,x
    return x+sx,y+sy
def checkpins(actual,exp,tag,sx=0,sy=0,a=0,m=False):
    ck(tag+' native rows',len(actual)==69*6,len(actual))
    def find(e,x,y,layer):
        rs=[r for r in actual if r['number']==e['number'] and close(r['x'],x) and close(r['y'],y) and r['layer']==layer]
        ck(tag+f' unique {e["number"]} {x},{y} {layer}',len(rs)==1)
        return rs[0]
    for e in exp:
        x,y=transform(e['x'],e['y'],sx,sy,a,m)
        for ly in ['ETCH/TOP','ETCH/BOTTOM','PIN/SOLDERMASK_TOP','PIN/SOLDERMASK_BOTTOM','PIN/PASTEMASK_TOP','PIN/PASTEMASK_BOTTOM']:
            p=find(e,x,y,ly)
            ck(tag+f' {e["number"]} local coordinates {ly}',close(p['relx'],e['x']) and close(p['rely'],e['y']) and close(p['rotation'],a) and (p['mirrored']=='t')==m)
            ck(tag+f' {e["number"]} mechanical flag {ly}',(p['mechanical']=='t')==e['mechanical'])
            if e['mechanical']:
                active='SOLDERMASK' in ly
                w=h=e['d']+.1 if active else 0
                figure='CIRCLE' if active else 'NULL'
                ck(tag+f' NPTH {x} drill {ly}',p['hole_type']=='circle_drill' and p['plating']=='NON_PLATED' and close(p['drill_diameter'],e['d']))
            else:
                side='BOTTOM' if m else 'TOP'
                active=ly.endswith('/'+side) or ly.endswith('_'+side)
                delta=.1 if 'SOLDERMASK' in ly else 0
                w,h=(e['w']+delta,e['h']+delta) if active else (0,0)
                if a==90:w,h=h,w
                figure=('OBLONG_X' if tag.startswith('lcsc') else 'RECTANGLE') if active else 'NULL'
                ck(tag+f' {e["number"]} no drill {ly}',p['hole_type']=='none' and close(p['drill_diameter'],0))
            ck(tag+f' {e["number"]} pad size/shape {ly}',close(p['w'],w) and close(p['h'],h) and p['figure']==figure,p)
            ck(tag+f' {e["number"]} copper/mask polygon {ly}',(p['poly_bbox']!='nil')==active)
            if active:
                bb=box(p['poly_bbox'])
                ck(tag+f' {e["number"]} true polygon bounds {ly}',len(bb)==4 and all(close(u,v) for u,v in zip(bb,[x-w/2,y-h/2,x+w/2,y+h/2])),bb)

package_data={}
for variant,exp in [('vendor',expected),('lcsc',expected_lcsc)]:
    r=B/'logs'/('read_'+variant)
    summary=(r/'summary.txt').read_text()
    ck(variant+' fresh native package readback','HC_READ COMPLETE' in summary and 'PIN_COUNT=69' in summary and 'drcs=0 drcState=t' in summary,summary)
    pins=table(r/'pins.tsv');geom=table(r/'geometry.tsv')
    package_data[variant]=pins
    checkpins(pins,exp,variant)
    for ly in ['REF DES/SILKSCREEN_TOP','REF DES/ASSEMBLY_TOP','COMPONENT VALUE/ASSEMBLY_TOP']:
        t=[g for g in geom if g['type']=='text' and g['layer']==ly]
        ck(variant+' text origin '+ly,len(t)==1 and close(t[0]['x'],0) and close(t[0]['y'],0) and close(t[0]['rotation'],0))
    bound=[g for g in geom if g['type']=='shape' and g['layer']=='PACKAGE GEOMETRY/PLACE_BOUND_TOP']
    ck(variant+' filled placement bound and 5.55 mm height',len(bound)==1 and bound[0]['filled']=='t' and '5.55 MM' in bound[0]['props'] and boxeq(bound[0],[-11.325,-4.03,11.325,4.03]),bound)
    ko=[g for g in geom if g['type']=='shape' and g['layer']=='ROUTE KEEPOUT/ALL']
    ck(variant+' two hole route keepouts',len(ko)==2 and all(k['filled']=='t' for k in ko))
    # Non-text silk must not overlap any solder-mask window.
    mask=[p for p in pins if p['layer']=='PIN/SOLDERMASK_TOP']
    for idx,g in enumerate([g for g in geom if g['layer']=='PACKAGE GEOMETRY/SILKSCREEN_TOP' and g['type']=='line']):
        for p in mask:
            bb=box(p['poly_bbox'])
            separate=float(g['x2'])<bb[0] or float(g['x1'])>bb[2] or float(g['y2'])<bb[1] or float(g['y1'])>bb[3]
            ck(variant+f' silk segment {idx} clears mask at {p["number"]}/{p["x"]}',separate)
    electrical=[p for p in pins if p['number'] and p['layer']=='ETCH/TOP']
    ck(variant+' symbol/package pin sets match',{p['number'] for p in electrical}==expected_numbers)
ck('main minimum copper gap 0.20 and mask web 0.10',close(.5-.3,.2) and close(.5-.4,.1))

bd=B/'logs/board_read'
bs=table(bd/'symbols.tsv');bp=table(bd/'pins.tsv');bg=table(bd/'geometry.tsv')
ck('all six compiled PSM instances reload',len(bs)==6 and len(bp)==414*6)
transforms=[('vendor',-25,0,0,False),('vendor',0,20,90,False),('vendor',25,0,0,True),('lcsc',-25,-20,0,False),('lcsc',0,-40,90,False),('lcsc',25,-20,0,True)]
for variant,sx,sy,a,m in transforms:
    instances=[s for s in bs if close(s['x'],sx) and close(s['y'],sy)]
    ck(f'{variant} instance {sx},{sy}',len(instances)==1 and int(instances[0]['pins'])==69 and close(instances[0]['rotation'],a) and (instances[0]['mirrored']=='t')==m)
    exp=expected if variant=='vendor' else expected_lcsc
    selected=[r for r in bp if any(close(r['x'],transform(p['x'],p['y'],sx,sy,a,m)[0]) and close(r['y'],transform(p['x'],p['y'],sx,sy,a,m)[1]) for p in exp)]
    checkpins(selected,exp,variant+f'_instance_{sx}_{sy}',sx,sy,a,m)
    corners=[transform(x,y,sx,sy,a,m) for x in [-11.325,11.325] for y in [-4.03,4.03]]
    expected_box=[min(p[0] for p in corners),min(p[1] for p in corners),max(p[0] for p in corners),max(p[1] for p in corners)]
    bounds=[g for g in bg if g['type']=='shape' and g['layer']=='PACKAGE GEOMETRY/PLACE_BOUND_'+('BOTTOM' if m else 'TOP') and boxeq(g,expected_box)]
    ck(f'{variant} {sx},{sy} transformed height shape',len(bounds)==1 and bounds[0]['filled']=='t' and '5.55 MM' in bounds[0]['props'])
    for prefix in ['REF DES/SILKSCREEN_','REF DES/ASSEMBLY_','COMPONENT VALUE/ASSEMBLY_']:
        texts=[g for g in bg if g['type']=='text' and g['layer']==prefix+('BOTTOM' if m else 'TOP') and close(g['x'],sx) and close(g['y'],sy)]
        ck(f'{variant} {sx},{sy} instance text anchor '+prefix,len(texts)==1)

def save_svg(name,svg):
    (B/(name+'.svg')).write_text(svg,encoding='utf-8')
    d=pymupdf.open(stream=svg.encode(),filetype='svg')
    d[0].get_pixmap().save(B/(name+'.png'))
def footprint_preview(variant):
    pins=package_data[variant]
    scale=60;cx=750;cy=390
    def xy(x,y):return cx+scale*x,cy-scale*y
    s=['<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="800" viewBox="0 0 1500 800">','<rect width="1500" height="800" fill="#101927"/>']
    def txt(x,y,t,size=20,col='#e5edf8'):
        s.append(f'<text x="{x}" y="{y}" font-family="Arial" font-size="{size}" fill="{col}" text-anchor="middle">{html.escape(t)}</text>')
    txt(750,40,'HYCW19M-05NGFF-530B | '+('Manufacturer recommended' if variant=='vendor' else 'LCSC pad comparison'),28)
    txt(750,77,'TOP / component view | native reopened geometry | all dimensions in mm',20,'#a8b8cb')
    def rect(bb,fill,stroke,width=2,rx=0):
        x,y=xy(bb[0],bb[3]);s.append(f'<rect x="{x}" y="{y}" width="{scale*(bb[2]-bb[0])}" height="{scale*(bb[3]-bb[1])}" fill="{fill}" stroke="{stroke}" stroke-width="{width}" rx="{rx}"/>')
    rect([-11.325,-4.03,11.325,4.03],'none','#7561a9',1)
    rect([-10.925,-2.85,10.925,2.85],'none','#5fc8dc',2)
    rect([5.575,-.75,6.675,.75],'none','#5fc8dc',2)
    for p in pins:
        if p['number'] and p['layer']=='ETCH/TOP':
            bb=box(p['poly_bbox']);rect(bb,'#edc25b','#ffe5a1',1,9 if variant=='lcsc' else 0)
            x,y=xy(float(p['x']),4.4 if float(p['y'])>0 else -4.6)
            txt(x,y,p['number'],16,'#ffe5a1')
        if p['mechanical']=='t' and p['layer']=='ETCH/TOP':
            x,y=xy(float(p['x']),float(p['y']));d=float(p['drill_diameter'])
            s.append(f'<circle cx="{x}" cy="{y}" r="{d*scale/2}" fill="#030a13" stroke="#f1f5f9" stroke-width="2"/>')
            txt(x,y+72,f'NPTH {d:.2f}',17,'#d1d9e5')
    txt(*xy(0,.65),'J* / VALUE',26)
    txt(*xy(0,-.35),'Origin (0,0) at locating-hole midpoint',18,'#9eafc5')
    txt(*xy(6.125,-1.25),'M KEY',15,'#5fc8dc')
    txt(750,714,'67 contacts | missing 59-66 | locating holes 20.00 apart | height max 5.55',22)
    txt(750,751,('Copper 0.30 x 1.55 | Y = +/-2.955 | RECTANGLE' if variant=='vendor' else 'Copper 0.30 x 1.20 | Y = +/-2.900 | OBLONG')+' | no-copper NPTHs',20,'#a8b8cb')
    txt(750,782,'Reference preview from native database readback; not a Cadence GUI screenshot',16,'#73859e')
    s.append('</svg>');save_svg('pcb_preview' if variant=='vendor' else 'pcb_lcsc_preview','\n'.join(s))
for variant in ['vendor','lcsc']:footprint_preview(variant)

# Symbol preview is derived from actual reopened positions, pin names, and body.
sp=table(V/'capture_vendor/pins.tsv')
s=['<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1580" viewBox="0 0 1000 1580">','<rect width="1000" height="1580" fill="white"/>']
def st(x,y,t,size=20,anchor='start',color='#18344e'):
    s.append(f'<text x="{x}" y="{y}" font-family="Arial" font-size="{size}" text-anchor="{anchor}" fill="{color}">{html.escape(t)}</text>')
scale=3.4;ox=160;oy=120
st(500,40,'HYCW19M-05NGFF-530B',28,'middle')
st(500,73,'OrCAD Capture | single unit | 67 visible passive pins',19,'middle')
s.append(f'<rect x="{ox}" y="{oy}" width="{200*scale}" height="{390*scale}" fill="#f4f7fa" stroke="#18344e" stroke-width="2"/>')
for p in sp:
    sx,sy,hx,hy=[int(p[k]) for k in ['startX','startY','hotX','hotY']]
    s.append(f'<line x1="{ox+sx*scale}" y1="{oy+sy*scale}" x2="{ox+hx*scale}" y2="{oy+hy*scale}" stroke="#18344e" stroke-width="2"/>')
    left=sx==0
    st(ox+sx*scale+(10 if left else -10),oy+sy*scale+7,p['name'],19,'start' if left else 'end')
    st(ox+(sx+hx)*scale/2,oy+sy*scale-5,p['number'],16,'middle','#6b4a10')
st(500,oy+315*scale,'M KEY - no contacts 59..66',19,'middle',color='#6b7280')
st(160,oy-20,'J?',24)
st(500,1490,'PCB Footprint = hycw19m_05ngff_530b',22,'middle')
st(500,1530,'P-number connector symbol; assign PCIe / SATA nets in the schematic',19,'middle')
st(500,1564,'Preview from native readback; not a Capture GUI screenshot',16,'middle',color='#6b7280')
s.append('</svg>');save_svg('schematic_preview','\n'.join(s))

warnings=[dict(file=str(p.relative_to(B)),lines=[l for l in p.read_text(errors='replace').splitlines() if 'warning' in l.lower() or 'warn-' in l.lower()])
          for p in (B/'logs').rglob('*') if p.is_file() and p.suffix.lower() in ['.jrl','.log']]
warnings=[w for w in warnings if w['lines']]
artifacts=[dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((B/'library').iterdir()) if p.suffix.lower() in ['.olb','.pad','.dra','.psm']]
result=dict(status='PASS',checks=len(checks),details=checks,artifacts=artifacts,native_warnings=warnings,
    scope='Cadence native save/compile/fresh-readback and top/90-degree/bottom PSM placement. Preview is database-derived. No GUI pixel audit, 3D mating, physical soldering, or complete PCB electrical design signoff.',
    warning_assessment='SPMHUT-48 initialization rounding: critical geometry checked at 0.001 mm. NPTH has no default internal pads: intentional copper-free mechanical holes. All task native imports exited normally.')
(V/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=result['status'],checks=len(checks),artifacts=len(artifacts),preview='pcb_preview.png')))
