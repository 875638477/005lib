hycw19m_05ngff_530b.dra
