#ifndef _FIRMWARE_H_
#define _FIRMWARE_H_

#include "VI5300_Config.h"


extern  uint8_t Firmware_Ranging[];
extern uint16_t LoadFirmware(void);

#endif


